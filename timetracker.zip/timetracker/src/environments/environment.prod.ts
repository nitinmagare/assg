export const environment = {
  production: true,
  apiEndpoint: 'http://localhost:8080'
};
